$(document).ready(function() {

    $('.slider').owlCarousel({
        margin:10,
        autoplay:true,
        loop:true,
        autoplayTimeout:3000,
        nav:true,
        dots:true,
        items:1
    });
  
});